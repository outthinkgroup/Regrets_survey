module.exports = {
  owner: "outthinkgroup",
  repo: "Regrets_survey",
  githubToken: process.env.AUTH,
  qualtricsToken: process.env.QUALTRICS_TOKEN,
  ipStackKey: process.env.IP_STACK_KEY,
  surveyId: process.env.SURVEY_ID,
};
